---
permalink: /
layout: default
title: "poststruct - audit what shipped"
description: "The zero-dependency CLI that audits the HTML that actually ships: the head module and the site module, the release ladder, and the packstruct pack system."
---

# poststruct

Zero-dependency CLI that audits the HTML that actually ships: head hygiene, link
integrity, DOM shape - with the exact per-check catalog and the pack system below.

```bash
npx poststruct audit dist/          # walks a baked tree, head + site modules
```

The structure family: [prestruct](https://github.com/dhaupin/prestruct) puts SEO
*in before* the build, [freestruct](https://github.com/dhaupin/freestruct) puts
SEO *in after* an SSG, and poststruct checks what both of them - and everyone
else - actually shipped.

## Where to go next

- **[The check catalog](/poststruct/checks)** - every check by module, each
  individually disableable, scoped to the files-on-disk contract.
- **[Packs](/poststruct/packs)** - the packstruct SPEC v1 shape, config-as-the-arm,
  and the first-class shape-pack catalog.
- **[GitHub](https://github.com/dhaupin/poststruct)** - the source, the release
  ladder, the deployment runbook.
