/**
 * pages/Home.jsx - the poststruct landing. Same shell contract as the rig:
 * usePageMeta lives in the component BODY (hook-order law - the crashtest
 * lesson), the .code pre carries the token classes the docs Rouge output
 * shares (.k/.cm), CTAs compose .btn + a color modifier (the base class
 * carries geometry).
 */
import usePageMeta from '../hooks/usePageMeta.js'

const SITE_URL = 'https://poststruct.creadev.org'

export default function Home() {
  usePageMeta({
    siteUrl: SITE_URL,
    path: '/',
    title: 'poststruct - audit what shipped',
    description: 'Zero-dependency CLI that walks baked HTML and verifies it against a head/site contract. FAIL findings exit non-zero so CI gates regressions.',
  })
  return (
    <>
      <section className="hero">
        <div className="wrap">
          <p className="eyebrow">poststruct - the audit leg</p>
          <h1>
            prestruct puts SEO <span className="accent">in before</span> the
            build. poststruct checks <span className="accent">what shipped.</span>
          </h1>
          <p className="lede">
            A zero-dependency CLI that walks a directory of baked HTML - any
            generator's output, JS or SSG or hand-rolled - and audits it against
            a head and site contract: titles and description bands, canonical,
            OG sets, JSON-LD, sitemap, robots, the 404 contract. FAIL findings
            exit non-zero, so CI gates regressions the day a route loses its
            metadata.
          </p>
          <div className="cta-row">
            <a className="btn btn-primary" href="https://github.com/dhaupin/poststruct">See the repo</a>
            <a className="btn btn-ghost" href="https://docs.creadev.org/poststruct/">Read the docs</a>
          </div>
          <pre className="code"><span className="cm"># the whole audit on a baked tree</span>{'\n'}npx <span className="k">poststruct</span> <span className="k">audit</span> dist/{'\n'}<span className="cm"># {'>'} head module findings + site contract, exit 1 on any FAIL</span></pre>
        </div>
      </section>
    </>
  )
}
