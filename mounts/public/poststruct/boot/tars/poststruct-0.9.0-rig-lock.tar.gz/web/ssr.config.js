export default {
  siteUrl:  'https://poststruct.creadev.org',
  siteName: 'poststruct',
  author:   'dhaupin',
  tagline:  'Audit what shipped.',
  ogImage:  'https://poststruct.creadev.org/og-image.png',
  keywords: 'poststruct, seo audit, baked html, head hygiene, sitemap, robots, canonical, open-graph, ci, prestruct, freestruct, struct-family',

  routes: [
    {
      path: '/',
      priority: '1.0',
      changefreq: 'monthly',
      meta: {
        title: 'poststruct - audit what shipped',
        description: 'Zero-dependency CLI that walks a directory of baked HTML - any generator\'s output - and verifies it against a head/site contract. FAIL findings exit non-zero so CI gates regressions.',
      },
    },
    {
      path: '/terms',
      priority: '0.3',
      changefreq: 'yearly',
      meta: {
        title: 'Terms | poststruct',
        description: 'Terms of use for the poststruct site and its documentation surfaces.',
      },
    },
    {
      path: '/privacy',
      priority: '0.3',
      changefreq: 'yearly',
      meta: {
        title: 'Privacy | poststruct',
        description: 'What this site collects: nothing hidden, no tracking states to find.',
      },
    },
    // one entry per Route in AppLayout.jsx
  ],

  // The static 404 the host serves every miss; the shape + copy match
  // pages/NotFound.jsx so host-not-found and hydrate-not-found read as one page.
  // Engine gate: prestruct#33 (function replacers ship literal $1/$2 into these
  // tags) closes at the engine fix - assert this file clean after the bump.
  notFound: {
    heading: '404',
    body: 'That page does not exist here.',
    primaryCta: { label: 'Back home', href: '/' },
  },
}
