# poststruct MANIFEST - the receipts

Every file in this tree is either (a) poststruct's own 0.9.0 core from the
lock tarball, (b) an extraction from the deployed flowforge rig, or (c) tiny
glue written for this unpacking. This table names which, at which reference,
so adopters can diff against sources and so bumping a pinned engine is a
deliberate review rather than a drift.

Rig extraction source: **dhaupin/flowforge @ `91e52e0`** (2026-10-25).
Core source: **dhaupin/poststruct-0.9.0 lock tar @ `dcb7755`** (2026-10-24),
history preserved (the tarball carries `.git`).

## src/ + bin/ + test/ (the product - the CLI itself)

| file | receipt |
|------|---------|
| `bin/cli.mjs`, `src/**`, `test/**`, `packs/` mount, `docs/checks.md`, `docs/packs.md` | poststruct's own 0.9.0 core, verbatim from the lock tar (mutations only: docs frontmatter permalinks de-prefixed for the rig gate). The CLI is the npm product; the rig wraps it, never rewrites it |
| `package.json` (root) | poststruct identity/exports untouched; added `docs:verify` + `docs:build` recipes (the rig's gates as one command) |
| `wrangler.toml`, `functions/api/health.js` | verbatim from the lock tar (Pages health canary) |

## web/ (prestruct landing shell, flowforge rig)

| file | receipt |
|------|---------|
| `vite.config.js`, `package-lock.json` | byte-exact copies |
| `src/App.jsx`, `src/main.jsx`, `src/islands.js`, `src/hooks/usePageMeta.js`, `src/AppLayout.jsx`, `src/components/ThemeSwitch.jsx`, `src/pages/NotFound.jsx` | byte-exact or comment-only edits (engine files - copy once, never edit) |
| `ssr.config.js` | rig shape; identity = poststruct (`poststruct.creadev.org`, tagline "Audit what shipped.", three routes + notFound block) |
| `src/pages/Home.jsx` | rig structure (usePageMeta-in-body law kept), copy = the PRD pitch |
| `src/components/Nav.jsx`, `navItems.js`, `Footer.jsx` | extracted; brand text + GitHub href = poststruct; header order kept |
| `src/styles.css` | token structure verbatim; accent re-tuned to audit green (#4cc38a family, dark + light halves) - values are brand, names are contract |
| `index.html` | theme key `poststruct-theme` (kept in sync with ThemeSwitch + the layout) |
| `public/_headers`, `_redirects`, `robots.txt`, `site.webmanifest` | byte-exact copies; identity strings swapped |

## docs/ (freestruct docs rig, flowforge cut)

| file | receipt |
|------|---------|
| `Gemfile`, `_layouts/default.html`, `discussions/index.md` | rig copies (layout theme key rekeyed to `poststruct-theme`) |
| `_config.yml` | poststruct's own (restored from HEAD), already fleet-shaped: no theme gem, kramdown GFM + rouge, baseurl `/poststruct` |
| `_data/nav.yml` | the rig's nav-starter lesson, poststruct entries (empty sidebar was the silent first-render gap in the crashtest cut) |
| `_freestruct/inject-brand.html`, `freestruct.config.yml` | rig glue; identity mirrors `_config.yml` (the `{{siteAuthor}}` placeholder is NOT in the pinned freestruct substitution table - the Organization block rides `{{siteName}}`/`{{siteUrl}}`, per the flowforge unpacking fix) |
| `docs/checks.md`, `docs/packs.md` | poststruct's own, restored from HEAD; permalinks made baseurl-relative for the rig gate |

## scripts/ (the docs gates)

| file | receipt |
|------|---------|
| `check-docs-frontmatter.cjs`, `check-docs-style.cjs`, `check-docs-links.cjs`, `check-fiction-signatures.cjs`, `check-jekyll-filters.cjs`, `check-language.cjs` | byte-exact rig copies, with ONE genericization each: frontmatter permalink rule and link checker now carry `/poststruct` and the doubled-poststruct-prefix class (the rig's own cut had hardcoded `crashtest` literals inside link-gate LOGIC, not just comments - genericized while unpacking), and `SITE_PREFIX` mirrors the baseurl |

## .github/workflows/

| file | receipt |
|------|---------|
| `test.yml`, `publish.yml`, `release.yml` | verbatim from the lock tar (the 0.9.0 manual -> OIDC release ladder is poststruct's own; publish already refuses 0.x tags) |
| `docs.yml` | poststruct's own pipeline (Jekyll -> musl pagefind -> freestruct strict -> Pages) with TWO rig-lesson patches: pagefind scrape now token-authenticated + refuses unparseable tags, and the gates step runs the full six-checker set |

## Engine pins (bump = deliberate review)

| engine | pin | why |
|--------|-----|-----|
| prestruct (web/) | `^1.1.0` (npm) | the prerender engine's current npm latest; the #33 function-replacer 404 leak ships in 1.1.0 - the web build GATE after the family's pending bump is `grep -c '\$[12]' web/dist/404.html == 0` (flowforge's repair-404.cjs is the stopgap pattern, deliberately NOT adopted here: the fix lands in the new prestruct, rig patch retires instead of forking) |
| freestruct (docs) | `freestruct@1.0.0` exact, npm (in docs.yml + build-docs.sh) | npm version pin on the deploy step; family is shipping a new freestruct - bump deliberately, one pin, same commit |
| pagefind | latest-resolve IN CI, token-authenticated, hard-refused on an unparseable tag | the flowforge receipt: unauthenticated scrapes get rate-limited from shared runner IPs |
| actions | pinned as in the copied workflows | |

## Unpacked-day decisions (2026-10-25)

- Staging: unpacked INSIDE the gistory workspace on the user's call - the
  tree is a self-contained repo (own `.git`, history intact) and must move to
  `dhaupin/poststruct` as the first push the day the repo is reconnected.
- Brand: `icon.svg` authored (stone plate + page + audit tick), byte-equal in
  `docs/icon.svg` and `web/public/icon.svg`; accent = audit green. Raster set
  (icon-192/512, favicon-32, apple-touch-icon, og-image) generated OUT-OF-TREE
  from the SVG (no rasterizer dep committed - the flowforge rule); regenerable
  from the SVG any time.
- `web/package-lock.json` refreshed against `poststruct@^1.1.0` at verify time
  (flowforge's lock carried `^1.0.0` resolutions).

## Bump procedure

1. Change the pinned SHA/version in the workflow or this table.
2. Run the verify suite: `npm test` (core), `npm run docs:verify` (gates),
   the web build + prerender from `web/`.
3. Land all of it (works + receipt bump) in the SAME commit - the rig's docs
   must never claim a state the workflows do not run.
