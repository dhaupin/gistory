# labs/TASKS.md - poststruct

Last updated: 2026-10-25 (rig unpacking landed; push pending dhaupin#18)

## Now
- [x] RIG UNPACKING (2026-10-25): the 0.9.0 lock tar unpacked into the
      gistory workspace by user call, and the flowforge rig extracted over
      it (dhaupin/flowforge @ 91e52e0): web/ landing (poststruct identity,
      audit-green tokens, routes /terms /privacy, icon.svg authored
      byte-equal across surfaces + out-of-tree rasters incl. og-image),
      docs/ rebuilt on the rig (nav starter, discussions sample, six
      checker gates), docs.yml pagefind token-auth patch, MANIFEST.md as
      the poststruct-cut receipt table. Core untouched (lock tar history
      intact; .git carried through). Verified: npm test 8/8 expected FAIL
      ids PASS; docs:verify six gates PASS (4 pages); web build 3/3 routes
      prerendered, brand meta injected, sitemap 3 locs. Known gate: the
      404 leak is upstream prestruct#33 shipping in 1.1.0 - assert
      `grep -c '\$[12]' web/dist/404.html == 0` right after tonight's
      engine bump (flowforge's repair-404 stopgap deliberately NOT adopted;
      fix lands at cause).
- [ ] PUSH to GitHub: the scaffold + rig are complete, the repo exists on GitHub,
      and push is 403 for freebuff-web[bot] (permission only, not not-found).
      Day action: Rook reconnects the repo to the
      Freebuff app, then the tree paints as-is (see MANIFEST bump procedure;
      staging currently lives inside the gistory workspace - MOVE the tree
      out before push, keep .git).
- [ ] Manual 0.9.0 npm publish the day the push lands (npm prep: a machine
      with npm credentials; DEPLOY.md is the runbook).

## Next (M1)
- [ ] Pack loader in core (packstruct SPEC v1, check profile): manifest
      validation, slug-namespaced ids, collision refusal. Local paths only.
- [ ] links module: internal link graph vs files present + `_redirects`;
      renamed route fails CI.
- [ ] First shape packs: wp-seo-shapes, jekyll-shapes, prestruct-shapes,
      freestruct-shapes (the engines' CI gains its guarantee through me).
- [ ] Optional `--check-external` link validation (network gate, opt-in),
      and re-add the scheduled weekly `linkcheck.yml` alongside it (removed
      at lock time: the 0.9.0 workflow called a CLI mode that did not
      exist, so it would have failed CI on the first push).

## Later (M2+)
- [ ] i18n + a11y-lite + language modules (dash classes, cliche lexicon,
      per-org voice packs), feeds module, npm-source pack loading.

## crashtest lane (deferred, with trigger)
- [ ] poststruct-site-shapes pack (crashtest scenario lane,
      crashtest.config.js + packs/public/) - trigger: the prestruct-example
      landing build exists. Surface to attack then: the /api/health Pages
      Function (in-process, prestruct-proxy precedent) + the baked tree via
      a static-site double (freestruct-docs-shapes precedent). Until then
      there is no transport surface worth an attack; the audit surface is
      covered by the negative-tested fixtures (8/8 expected FAIL ids).
